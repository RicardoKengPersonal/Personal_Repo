#include <stdio.h>

int find_nums(int *arr, int len, int n, int **res)
{
    int found_count = 0; // contador de vezes que é encontrado
    int *p = NULL;         // inicialização do ponteiro
    int **r = res;          // inicializacao do ponteiro
    
                   // endereco de p = endereco do array

    for (p = arr; p < arr + len; p++)
    {
        if(n == *p) // se o elemento a procurar for igual ao elemento apontado por p
        {
            found_count++;
            *r = p;     // conteudo do array r = endereco de p 
            r++;        // proximo ponteiro do array r
        }
    }

    return found_count;
}

int main()
{
    int arr[]={1,4,2,3,4,4};        // array que guarda valores do tipo int
    int *res[]={NULL,NULL,NULL,NULL,NULL,NULL}; // array que guarda valores do tipo ponteiros de inteiros
    int search = 4;

    int result = find_nums(arr,6,search,res);

    printf("Number %d found %d times.\n",search,result);

    return 0;
}