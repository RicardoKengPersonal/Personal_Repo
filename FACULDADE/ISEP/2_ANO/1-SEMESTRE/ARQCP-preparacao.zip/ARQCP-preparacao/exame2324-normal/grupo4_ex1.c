#include <stdio.h>

typedef struct {
    unsigned short number;
    char name[80];
}student_t;

typedef struct {
    char designation[20];
    unsigned short student_count;
    student_t **students;
}class_t;

int main()
{
    return 0;
}