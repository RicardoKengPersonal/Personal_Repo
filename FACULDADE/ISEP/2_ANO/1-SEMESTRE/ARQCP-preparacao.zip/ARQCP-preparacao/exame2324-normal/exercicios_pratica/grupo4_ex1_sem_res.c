#include <stdio.h>
#include <stdlib.h>

typedef struct {
    unsigned short number;
    char name[80];
} student_t;

typedef struct {
    char designation [20];
    unsigned short n_students;
    student_t **students;
} class_t;

void add_students_to_class(class_t *c, student_t *s)
{
    c->n_students++; // student count ++

    if(c->n_students == 1)
    {
        c->students = (student_t**)malloc(sizeof(student_t*)); // alocacao de memoria para 1 aluno
    }else
    {
        c->students = (student_t**)realloc(c->students,sizeof(student_t*)*c->n_students); // alocacao de memoria para mais que um aluno
    }

    c->students[c->n_students - 1] = s; // coloca no array students a instancia
}

int main()
{
    return 0;
}