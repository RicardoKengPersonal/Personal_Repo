#include <stdio.h>

int find_nums(int *arr, int len, int n, int** res)
{
    int found = 0;
    int* p = NULL;      //inicializacao do ponteiro
    int **r = NULL;
    r = res;

    for(p = arr; p < len + arr; p++)
    {
        if(n == *p)
        {
            found ++; // found counter ++
            *r = p;     // conteudo de r = endereco do elemento
            r++;        // proximo elemento do array
        }
    }

    return found;
}

void print_addr(int **parr, int len)
{
    int **ptr = NULL; // inicializacao do ptr

    for(ptr = parr; ptr < parr +  len; ptr++)
    {
        if(*ptr != NULL) // se o conteudo de p nao for NULL faz print
        {
            printf("Addres: %p\n",ptr); // se nao for null faz print do endereco que esta em p
        }
    }
}

int main()
{
    int arr[]={1,4,2,3,4,4};
    int *res[]={NULL,NULL,NULL,NULL,NULL,NULL};
    int search = 4;


    for (int i = 0; i < 6; i++)
    {
        printf("Arr[%d] = %d\n",i,arr[i]);
    }

    int result = find_nums(arr,6,search,res);

    printf("%d found %d times.\n",search, result);

    print_addr(res,6);

    return 0;
}