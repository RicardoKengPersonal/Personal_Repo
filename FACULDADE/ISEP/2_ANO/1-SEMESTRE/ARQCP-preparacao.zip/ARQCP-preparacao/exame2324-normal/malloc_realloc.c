#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *arr = NULL;

    arr = (int*)malloc(5*sizeof(int));

    if (arr == NULL)
    {
        printf("Malloc error.\n");
        exit(1);
    }

    int *p = NULL;
    int i = 0;

    for (p = arr;p < arr + 5; p++)
    {
        *p = i;
        i++;
    }

    printf("Created array:\n");

    for(p = arr; p < arr + 5; p++)
    {
        printf("Element added: %d\n",*p);
    }

    arr = (int*)realloc(arr,6*sizeof(int));

    if( arr == NULL)
    {
        printf("Realloc error.\n");
        exit(1);
    }

    for(p = arr; p < arr + 6; p++)
    {
        *p = i + 1;
        i++;
    }

    for(p = arr; p < arr + 6; p++)
    {
        printf("Element added (new array): %d\n",*p);
    }

    free(arr);
    return 0;
}