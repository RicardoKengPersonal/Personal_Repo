#include <stdio.h>

int find_nums(int *arr, int len, int n, int **res)
{
    int found_count = 0; // contador de vezes que é encontrado
    int *p = NULL;         // inicialização do ponteiro
    int **r = res;          // inicializacao do ponteiro
    p = arr;                // endereco de p = endereco do array

    for (p; p < arr + len; p++)
    {
        if(n == *p) // se o elemento a procurar for igual ao elemento apontado por p
        {
            found_count++;
            *r = p;     // conteudo do array r = endereco de p 
            r++;        // proximo ponteiro do array r
        }
    }

    return found_count;
}

void print_addr(int** parr, int len)
{
    int **ptr = NULL; // inicializa um pointer do tipo int* (por isso é que leva dois *)

    printf("Addresses where the number was found:\n");
    
    // Endereco de ptr = endereco de parr
    for(ptr = parr; ptr < parr + len; ptr++)
    {
        printf("Adress: %p\n",*ptr); // *ptr, porque queremos que faca print do conteudo do array parr
                                     // se fosse so ptr, faria print dos enderecos de cada elemento do array 
                                     // e nao do conteudo
                                     // se fosse dois * faria print do valor que esta na memoria guardada
                                     // no array , no caso 4 porque 4 era o numero a ser procurado
    }
}

int main()
{
    int arr[]={1,4,2,3,4,4};        // array que guarda valores do tipo int
    int *res[]={NULL,NULL,NULL,NULL,NULL,NULL}; // array que guarda valores do tipo ponteiros de
    int search = 4;

    int result = find_nums(arr,6,search,res);

    printf("Number %d found %d times.\n",search,result);

    print_addr(res,result);

    return 0;
}