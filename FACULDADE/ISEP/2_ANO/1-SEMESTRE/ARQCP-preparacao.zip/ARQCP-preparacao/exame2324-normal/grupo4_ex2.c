#include <stdio.h>
#include <stdlib.h>
#include <string.h>  // For strcpy()

typedef struct {
    unsigned short number;
    char name[80];
} student_t;

typedef struct {
    char designation[20];
    unsigned short student_count;
    student_t **students;
} class_t;

void add_student_to_class(class_t *c, student_t *s)
{
    c->student_count++;  // Increment the student count
    
    // Allocate memory for the students array if it's the first student
    if (c->student_count == 1) {
        c->students = (student_t**)malloc(sizeof(student_t*));
    } else {
        // Reallocate memory for the students array when adding more students
        c->students = (student_t**)realloc(c->students, sizeof(student_t*) * c->student_count);
    }
    
    // Add the student to the array
    c->students[c->student_count - 1] = s;
}

int main()
{
    // Create a class and initialize it
    class_t my_class;
    my_class.student_count = 0;  // Start with no students
    my_class.students = NULL;    // No students initially
    strcpy(my_class.designation, "Math 101");  // Directly copy the class designation

    // Create and add students to the class
    student_t *student1 = (student_t*)malloc(sizeof(student_t));
    student1->number = 101;
    strcpy(student1->name, "John Doe");  // Directly copy the student's name
    add_student_to_class(&my_class, student1);

    student_t *student2 = (student_t*)malloc(sizeof(student_t));
    student2->number = 102;
    strcpy(student2->name, "Jane Smith");  // Directly copy the student's name
    add_student_to_class(&my_class, student2);

    student_t *student3 = (student_t*)malloc(sizeof(student_t));
    student3->number = 103;
    strcpy(student3->name, "Jim Brown");  // Directly copy the student's name
    add_student_to_class(&my_class, student3);

    // Print class details
    printf("Class: %s\n", my_class.designation);
    printf("Number of students: %d\n", my_class.student_count);
    for (int i = 0; i < my_class.student_count; i++) {
        printf("Student %d: %s (ID: %d)\n", i + 1, my_class.students[i]->name, my_class.students[i]->number);
    }

    // Free dynamically allocated memory for students
    for (int i = 0; i < my_class.student_count; i++) {
        free(my_class.students[i]);
    }
    free(my_class.students);  // Free the array of pointers to students

    return 0;
}
