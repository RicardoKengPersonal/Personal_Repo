#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct {
    unsigned short number; // Número do estudante
    char name[80];         // Nome do estudante
} student_t;

// Novo tipo de dados para representar uma turma
typedef struct {
    char name[50];         // Designação da turma (ex.: "Turma A")
    student_t *students;   // Apontador para o array de estudantes
    unsigned short count;  // Número de estudantes na turma
} class_t;

int main() {
    // Definição de todos os estudantes disponíveis
    student_t all_students[] = {
        {1, "Manuel Ferreira"},
        {2, "Maria Joaquina"},
        {3, "Carlos Alberto"},
        {4, "Ana Carolina"}
    };

    // Criação de uma turma
    class_t turmaA;
    strcpy(turmaA.name, "Turma A"); // Nome da turma

    // Alocar espaço inicial para 2 estudantes da turma
    turmaA.students = malloc(2 * sizeof(student_t));
    if (turmaA.students == NULL) {
        printf("Erro ao alocar memória!\n");
        return 1;
    }
    turmaA.count = 0; // Inicializa o número de estudantes na turma

    // Adicionar os dois primeiros estudantes à turma
    turmaA.students[0] = all_students[0]; // Manuel Ferreira
    turmaA.students[1] = all_students[1]; // Maria Joaquina
    turmaA.count = 2; // Atualiza o número de estudantes na turma

    // Realoque memória para adicionar mais um estudante
    turmaA.students = realloc(turmaA.students, 3 * sizeof(student_t));
    if (turmaA.students == NULL) {
        printf("Erro ao realocar memória!\n");
        return 1;
    }

    // Adicionar o terceiro estudante
    turmaA.students[2] = all_students[2]; // Carlos Alberto
    turmaA.count++; // Incrementa o número de estudantes na turma

    // Exibir informações da turma
    printf("Turma: %s\n", turmaA.name);
    printf("Número de estudantes: %d\n", turmaA.count);

    for (int i = 0; i < turmaA.count; i++) {
        printf("Estudante %d: %s\n", turmaA.students[i].number, turmaA.students[i].name);
    }

    // Liberar memória alocada dinamicamente
    free(turmaA.students);

    return 0;
}
