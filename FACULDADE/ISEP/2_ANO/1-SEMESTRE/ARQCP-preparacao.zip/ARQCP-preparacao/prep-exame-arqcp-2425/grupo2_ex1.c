#include <stdio.h>
#include <stdlib.h>

// Função para encontrar números
int find_nums(int *arr, int len, int n, int **res) 
{
    int count = 0; // Contador de ocorrências

    for (int i = 0; i < len; i++) 
    {
        if (arr[i] == n) 
        {
            res[count] = &arr[i]; // Salva o endereço do elemento encontrado
            count++;
        }
    }
    return count; // Retorna o número de ocorrências
}

//alinea 2

// Função para imprimir os endereços armazenados no array parr
void print_addr(int **parr, int len) 
{
    for (int i = 0; i < len; i++) {
        printf("Address %d: %p\n", i, *(parr + i)); // Aritmética de ponteiros
    }
}

int main() 
{
    int arr[] = {1, 4, 2, 3, 4, 4}; // Array a ser pesquisado
    int len = sizeof(arr) / sizeof(arr[0]); // Comprimento do array

    int *res[] = {NULL,NULL,NULL,NULL,NULL,NULL}; // Array para armazenar os ponteiros dos resultados

    int search = 4; // Número a ser procurado
    printf("The number to search: %d\n", search);

    // Chama a função find_nums
    int occurrences = find_nums(arr, len, search, res);

    // Exibe o número de vezes que o número aparece
    printf("Number of times %d appears in the array: %d\n", search, occurrences);

    // Exibe os índices onde o número foi encontrado
    if (occurrences > 0) 
    {
        printf("Indices where %d is found:\n", search);
        print_addr(res,occurrences);
    } else {
        printf("%d is not found in the array.\n", search);
    }

    return 0;
}
