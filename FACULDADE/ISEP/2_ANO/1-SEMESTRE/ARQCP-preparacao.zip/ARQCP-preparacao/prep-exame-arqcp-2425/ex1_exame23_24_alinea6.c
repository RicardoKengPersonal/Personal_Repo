#include <stdio.h>

int main()
{
    short x = 0x1234;

    printf("Valor de x: %d\n",x);

    short res1 = ~x;

    printf("Valor de ~x: %d\n",res1);

    short res2 = ~x-1;

    printf("Valor de ~x-1: %d\n",res2);

    printf("Print test.\n");

    return 0;
}