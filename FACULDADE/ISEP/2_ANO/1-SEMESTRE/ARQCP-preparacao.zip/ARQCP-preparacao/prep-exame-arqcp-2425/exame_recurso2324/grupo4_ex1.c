#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CLASSES_LEN 50

// Definição de student_t
typedef struct {
    unsigned short number;
    char name[80];
} student_t;

// Definição de class_t
typedef struct {
    char designation[20];
    student_t **students;
    unsigned short n_students;
} class_t;

// Função para adicionar um estudante à turma
void add_student_to_class(class_t *c, student_t *s) 
{
    c->n_students++;

    if (c->n_students == 1)
    {
        c->students = (student_t **)malloc(sizeof(student_t *));
    } else {
        c->students = (student_t **)realloc(c->students, sizeof(student_t *) * c->n_students);
    }

    if (c->students == NULL) 
    {
        printf("Erro ao alocar memória!\n");
        exit(1);
    }

    c->students[c->n_students - 1] = s;
}

int main() {
    // Definição dos estudantes
    student_t students[] = 
    {
        {1, "Manuel Ferreira"},
        {2, "Maria Joaquina"},
        {3, "Carlos Alberto"},
        {4, "Ana Carolina"}
    };

    // Alocação do array de turmas
    class_t *classes = (class_t *)calloc(CLASSES_LEN, sizeof(class_t));

    if (classes == NULL) 
    {
        printf("Erro ao alocar memória para as turmas!\n");
        exit(1);
    }

    // Adicionar estudantes às turmas
    strcpy(classes[0].designation, "Turma A");
    add_student_to_class(&classes[0], &students[0]);
    add_student_to_class(&classes[0], &students[1]);

    strcpy(classes[1].designation, "Turma B");
    add_student_to_class(&classes[1], &students[2]);
    add_student_to_class(&classes[1], &students[3]);

    // Exibir informações das turmas
    for (int i = 0; i < CLASSES_LEN; i++) 
    {
        if (classes[i].n_students > 0) {
            printf("Turma: %s\n", classes[i].designation);
            printf("Número de Estudantes: %d\n", classes[i].n_students);
            for (int j = 0; j < classes[i].n_students; j++) {
                printf("Estudante %d: %s\n", classes[i].students[j]->number, classes[i].students[j]->name);
            }
            printf("\n");
        }
    }

    // Libertar a memória
    for (int i = 0; i < CLASSES_LEN; i++) 
    {
        if (classes[i].students != NULL) 
        {
            free(classes[i].students); // Liberar o array de ponteiros para student_t
        }
    }

    free(classes); // Liberar o array de class_t

    return 0;
}
 