#include <stdio.h>

void func1(int *a, int *b) {
    *a += *b;
    *a += *b;
}

void func2(int *a, int *b) {
    *a += 2 * (*b);
}

int main() {
    int a = 5;
    int *b = &a;  // Agora b aponta para o mesmo endereço que a

    // Teste com func1
    int a1 = a;
    func1(&a1, b);
    printf("Resultado com func1: %d\n", a1);

    // Teste com func2
    int a2 = a;
    func2(&a2, b);
    printf("Resultado com func2: %d\n", a2);

    return 0;
}
