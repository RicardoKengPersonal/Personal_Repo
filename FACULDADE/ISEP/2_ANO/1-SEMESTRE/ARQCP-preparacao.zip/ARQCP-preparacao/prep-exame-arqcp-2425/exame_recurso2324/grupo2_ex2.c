#include <stdio.h>

void invert_bytes(int *arr, int len) 
{
    // Percorre o array de inteiros
    for (int i = 0; i < len; i++) 
    {
        unsigned char *ptr = (unsigned char *)&arr[i];  // Ponteiro para os bytes do número

        // Inverte os bytes usando uma variável temporária
        unsigned char temp;
        temp = ptr[0];
        ptr[0] = ptr[3];
        ptr[3] = temp;

        temp = ptr[1];
        ptr[1] = ptr[2];
        ptr[2] = temp;
    }
}

int main() 
{
    // Definindo um array com valores em hexadecimal
    int vec[] = {0x00CDABCD, 0x00AABCDE, 0x6677CBEF};

    // Antes da troca
    for (int i = 0; i < 3; i++)
    {
        printf("vec[%d] = 0x%08X\n",i,vec[i]);
    }

    printf("\n\nBytes invertidos:\n\n");

    // Chamando a função para inverter os bytes
    invert_bytes(vec, 3);

    // Exibindo o resultado após a inversão dos bytes
    for (int i = 0; i < 3; i++) 
    {
        printf("vec[%d] = 0x%08X\n", i, vec[i]);
    }

    return 0;
}
