#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição de `student_t` e `class_t`
typedef struct {
    unsigned short number;
    char name[80];
} student_t;

typedef struct {
    char name[50];
    student_t *students;  // Ponteiro para um array de estudantes
    unsigned short count; // Número de estudantes na turma
} class_t;

// Função para adicionar um estudante à turma
void add_student_to_class(class_t *c, student_t *s) 
{
    c->students = realloc(c->students, (c->count + 1) * sizeof(student_t));

    if (c->students == NULL) 
    {
        printf("Erro ao alocar memória!\n");
        exit(1);
    }
    c->students[c->count] = *s;
    c->count++;
}

int main() {
    // Lista de estudantes disponíveis
    student_t all_students[] = {
        {1, "Manuel Ferreira"},
        {2, "Maria Joaquina"},
        {3, "Carlos Alberto"},
        {4, "Teste"}
    };

    // Inicialização da turma
    class_t turmaA;
    strcpy(turmaA.name, "Turma A");
    turmaA.students = NULL; // Inicialmente, nenhuma memória alocada
    turmaA.count = 0;

    // Adicionando estudantes à turma
    add_student_to_class(&turmaA, &all_students[0]); // Adiciona "Manuel Ferreira"
    add_student_to_class(&turmaA, &all_students[1]); // Adiciona "Maria Joaquina"
    add_student_to_class(&turmaA, &all_students[2]); // Adiciona "Carlos Alberto"
    add_student_to_class(&turmaA, &all_students[3]); // Adiciona "Carlos Alberto"

    // Exibindo informações da turma
    printf("Turma: %s\n", turmaA.name);
    printf("Número de estudantes: %d\n", turmaA.count);
    for (int i = 0; i < turmaA.count; i++) {
        printf("Estudante %d: %s\n", turmaA.students[i].number, turmaA.students[i].name);
    }

    // Liberar memória alocada dinamicamente
    free(turmaA.students);

    return 0;
}
