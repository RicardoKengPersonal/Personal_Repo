#include <stdio.h>

void invert_bytes(int* arr, int len)
{
    int *p = NULL; // inicializacao do ponteiro
    p = arr; // endereco de p = endereco do array

    unsigned char *b = NULL; // inicializacao do ponteiro que vai buscar cada byte ao numero do array
    unsigned char c = 0; // variavel temporal apenas

    for (p; p < arr + len; p++)
    {
        b = (unsigned char*) p; // endereco do b passa a ser igual ao endereco o primeiro byte to elemento
                                // apontado por p
        c = *b;                 // guarda em c o primeiro byte

        *b = *( b + 3 );        // coloca no primeiro byte o 4 byte (apontado por b + 3)

        *( b + 3 )= c;          // 4 byte do elemento apontado por b = c
        c = *( b + 1);          // c = 2 byte do elemento apontado por b 
        *( b + 1) = *( b + 2);  // 2 byte = 3 byte 
        *( b + 2 ) = c;         // 3 byte = 2 byte
    }
}

int main()
{
    int vec[] = {0x00CDABCD,0x00AABCDE,0x6677CBEF};

    printf("Before inversion:\n");

    for (int i = 0; i < 3; i++)
    {
        printf("Vec[%d] = 0x%08X\n",i,vec[i]);
    }

    invert_bytes(vec,3);
    printf("After inversion:\n");

    for(int i = 0; i < 3; i++)
    {
        printf("Vec[%d] = 0x%08X\n",i,vec[i]);
    }
    //vec [0] = 0xCDABCD00
    //vec [1] = 0xDEBCAA00
    //vec [2] = 0xEFCB7766

    return 0;
}
