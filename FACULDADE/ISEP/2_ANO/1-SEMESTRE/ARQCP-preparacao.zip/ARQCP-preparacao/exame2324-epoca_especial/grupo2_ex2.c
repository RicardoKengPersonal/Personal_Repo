#include <stdio.h>

void remove_duplicates(char * str)
{
    char * p = str;
    char * p1 = NULL;
    char * p2 = NULL;
    char inc;

    while(*p !='\0') 
    {
        inc = 1;
        for (p1 = p + 1; *p1 != '\0'; p1++) 
        {
            if (*p1 == *p) 
            {
                for (p2 = p1; *p2 != '\0'; p2++) 
                {
                    *p2 = *(p2 + 1);
                }
                inc = 0;
            }
        }
        if (inc)
        p++;
    }
}


int main()
{
    char str[]="abababccab";

    printf("%s\n",str);

    remove_duplicates(str);

    printf("%s\n",str);

    return 0;
}