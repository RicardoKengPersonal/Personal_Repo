#include <stdio.h>
#include <stdlib.h>
#include <string.h>

    typedef struct {
        short number;
        int grades[5];
        char age;
        char name[60];
        char address[100];
    } Student;

void fill_student(Student *s, char age, short number, char *name, char *address) 
{
    s->age = age; // Register age
    s->number = number; // Register number
    strcpy(s->name,name);   // Register name
    strcpy(s->address, address);    // Register address
}

int main()
{
    Student students[5]; // Statically allocate an array of 5 elements

    fill_student(&students[0],20,12,"Ricardo","Rua 14");
    fill_student(&students[1], 21, 102, "Bob", "5678 Dreamland");
    fill_student(&students[2], 22, 103, "Charlie", "9101 Fantasyland");
    fill_student(&students[3], 23, 104, "David", "1122 Reality Lane");
    fill_student(&students[4], 24, 105, "Eva", "3344 Illusion Street");

    printf("Registered students:\n");

    for(int i = 0; i < 5; i++)
    {
        printf("Student name: %s\t Student number: %d\t Student Address: %s\n",students[i].name, students[i].number,
        students[i].address);
    }

    return 0;
}