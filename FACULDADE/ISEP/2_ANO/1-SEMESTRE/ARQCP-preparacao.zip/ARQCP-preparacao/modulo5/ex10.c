#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to dynamically create a new string with the exact size needed
char *new_str(char str[80]) 
{
    // Find the length of the input string
    size_t length = strlen(str);
    
    // Dynamically allocate memory for the new string (+1 for the null terminator)
    char *new_string = (char *)malloc((length + 1) * sizeof(char));
    
    // Check if memory allocation was successful
    if (new_string == NULL) 
    {
        printf("Memory allocation failed.\n");
        return NULL;
    }
    
    // Copy the content of the input string into the newly allocated memory
    strcpy(new_string, str);
    
    // Return the address of the newly created string
    return new_string;
}

int main() 
{
    // Test the new_str function
    char input[80] = "Hello, dynamic memory!";
    char *output = new_str(input);

    if (output != NULL) 
    {
        printf("Original string: %s\n", input);
        printf("New string: %s\n", output);
        
        // Free the dynamically allocated memory
        free(output);
    }

    return 0;
}

/*
Why It Is Possible to Return the Address:

The memory allocated by malloc resides in the heap memory, which persists beyond the scope of the 
function that allocates it. Unlike local variables, which are destroyed when the function returns, 
dynamically allocated memory is not automatically freed until explicitly released using free.
Therefore, returning the pointer to the dynamically allocated memory (new_string) is safe and valid 
because the memory remains accessible to the caller until it is explicitly freed.

*/
