#include <stdio.h>

int main()
{
    union union_u1 {
        char vec[32];
        float a;
        int b;
    }u;

    struct struct_s1{
        char vec[32];
        float a;
        int b;
    }s;

    printf("Size of union u: %d\n",sizeof(u));
    printf("Size of struct s: %d\n",sizeof(s));

    return 0;
}