int count_value(int vec[],int n, int value);
int cmp(int a,int b);
