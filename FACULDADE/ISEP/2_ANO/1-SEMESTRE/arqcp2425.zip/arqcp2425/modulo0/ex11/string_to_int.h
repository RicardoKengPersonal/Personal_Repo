int get_ascii_code(char c);
int string_to_int(char str[]);
