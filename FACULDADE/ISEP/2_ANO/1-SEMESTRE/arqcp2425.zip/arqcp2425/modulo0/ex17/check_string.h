int check_string(char str[], int h);
int fake_hash(char str[]);
int get_ascii_code(char c);
int soma (int a, int b);
