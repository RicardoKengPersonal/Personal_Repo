int average(int n1, int n2);
int average_array(int v[],int n);
