int find_pattern(char str[], char patt[]);
int cmp(int a, int b);

