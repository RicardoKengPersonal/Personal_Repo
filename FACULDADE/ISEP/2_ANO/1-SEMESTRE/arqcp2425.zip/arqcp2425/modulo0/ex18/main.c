#include <stdio.h>
#include "find_pattern.h"

int main()
{
	
}
