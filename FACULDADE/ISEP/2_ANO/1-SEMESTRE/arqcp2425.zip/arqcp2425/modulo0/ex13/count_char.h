int count_char(char str[],int c);
char get_ascii_char(int c);
