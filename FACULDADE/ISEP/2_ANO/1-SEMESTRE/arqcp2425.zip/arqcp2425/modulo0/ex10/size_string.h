unsigned int size_string_wrong (char s[]);
unsigned int size_string_correct (char s[]);
