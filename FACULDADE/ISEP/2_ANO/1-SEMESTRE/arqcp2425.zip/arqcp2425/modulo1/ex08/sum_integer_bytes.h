int sum_integer_bytes(unsigned int *p);
