void swap_nums(int* x,int* y);
void swap_pointers(char** x,char** y);
