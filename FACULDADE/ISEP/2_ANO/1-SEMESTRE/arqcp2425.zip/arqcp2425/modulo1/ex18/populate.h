void populate(unsigned char *vec, int num, int limit);
