int check(int x, int y, int z)
{
	return (x < y && y < z);
}
