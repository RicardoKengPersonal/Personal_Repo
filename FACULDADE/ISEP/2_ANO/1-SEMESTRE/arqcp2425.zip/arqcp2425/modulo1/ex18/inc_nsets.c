int num_sets=0;

void inc_nsets() 
{
    num_sets++;
}
