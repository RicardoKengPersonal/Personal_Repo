void swap(short *vec1, short *vec2, int size);
