void capitalize(char *str);
