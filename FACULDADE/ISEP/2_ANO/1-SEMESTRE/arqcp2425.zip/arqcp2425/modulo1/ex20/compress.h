void compress(int* vec_ints, int n, long* vec_longs);
