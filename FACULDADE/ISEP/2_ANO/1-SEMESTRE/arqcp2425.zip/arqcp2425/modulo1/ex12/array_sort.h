void array_sort(int* vec, int n);
