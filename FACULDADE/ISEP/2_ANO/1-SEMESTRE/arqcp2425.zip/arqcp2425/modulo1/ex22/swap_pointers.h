void swap_pointers(int **b, int **s, int n);
