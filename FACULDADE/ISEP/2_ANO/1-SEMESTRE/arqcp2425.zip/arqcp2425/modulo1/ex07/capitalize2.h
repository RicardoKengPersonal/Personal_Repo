void capitalize2(char *str);
