void format_word(char *str);
