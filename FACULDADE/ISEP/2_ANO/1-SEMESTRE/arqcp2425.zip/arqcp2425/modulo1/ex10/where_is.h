char* where_is(char* str, char c);
