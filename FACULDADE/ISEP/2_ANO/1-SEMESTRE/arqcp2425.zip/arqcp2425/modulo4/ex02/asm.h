#ifndef ASM_H
#define ASM_H

long sum2_n(int n);

#endif
