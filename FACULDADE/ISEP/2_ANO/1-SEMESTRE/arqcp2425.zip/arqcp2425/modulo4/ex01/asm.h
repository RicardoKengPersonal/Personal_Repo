#ifndef ASM_H
#define ASM_H
long d_square(int x);
#endif
