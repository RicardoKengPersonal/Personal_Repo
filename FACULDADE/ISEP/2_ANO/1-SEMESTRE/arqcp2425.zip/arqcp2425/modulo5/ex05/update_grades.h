void update_grades(Student *s, int *new_grades);
