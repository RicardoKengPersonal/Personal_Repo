#ifndef FUNC_H
#define FUNC_H
int **add_matrixes(int **a, int **b, int y, int k);
#endif