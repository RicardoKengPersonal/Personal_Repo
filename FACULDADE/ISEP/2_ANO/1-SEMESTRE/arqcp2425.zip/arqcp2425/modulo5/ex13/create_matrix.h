short **new_matrix(int lines, int columns);
