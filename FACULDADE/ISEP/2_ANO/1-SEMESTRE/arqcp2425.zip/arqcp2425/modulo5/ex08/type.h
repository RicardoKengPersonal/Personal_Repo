typedef struct {
	char c[3];
	short w[3];
	int j;
} s2;
