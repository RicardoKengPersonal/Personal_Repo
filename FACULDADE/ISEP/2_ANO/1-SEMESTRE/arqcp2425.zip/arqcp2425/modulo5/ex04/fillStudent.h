void fill_student(Student *s, char age, short number, char *name, char *address);
