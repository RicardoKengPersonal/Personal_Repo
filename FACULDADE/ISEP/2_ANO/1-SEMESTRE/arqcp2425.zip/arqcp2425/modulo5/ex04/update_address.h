void update_address(Student* s, char* new_address);
