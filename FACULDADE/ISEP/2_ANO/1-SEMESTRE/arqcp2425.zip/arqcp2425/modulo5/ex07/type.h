typedef struct {
	char c;
	int i;
	char d;
	int j;
} s1;
