typedef struct {
	int y;
	short x;
} structA;
