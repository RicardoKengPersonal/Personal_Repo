short fun1(structB *s);
short fun2(structB *s);
short* fun3(structB *s);
short fun4(structB *s);	
