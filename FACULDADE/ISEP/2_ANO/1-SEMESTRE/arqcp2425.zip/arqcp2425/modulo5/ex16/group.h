typedef struct{
	short n_students;
	unsigned short *individual_grades;
}group;
