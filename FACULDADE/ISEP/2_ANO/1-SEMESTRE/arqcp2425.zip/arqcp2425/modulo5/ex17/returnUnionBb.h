char return_unionB_b(structA **matrix, int i, int j);
