typedef struct {
	short int a[3];
	char b;
	long long int c;
	short d;
	char e;
	unionB ub;
}structA;
