typedef union {
	int a;
	char b;
	short c;
	long int d;
}unionB;
