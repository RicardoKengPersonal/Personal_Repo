typedef struct {
	long *stack; 
	int n;
} Stack;
