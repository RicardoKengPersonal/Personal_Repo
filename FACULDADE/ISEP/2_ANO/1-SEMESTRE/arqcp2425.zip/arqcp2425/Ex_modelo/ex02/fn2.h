#ifndef FN2_H
#define FN2_H
	void fn2(int *x);
#endif
