#ifndef ASM_H
#define ASM_H
int format_command(char* op, int n, char* cmd);
#endif
