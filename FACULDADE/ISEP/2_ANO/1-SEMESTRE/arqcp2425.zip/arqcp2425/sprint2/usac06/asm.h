#ifndef ASM_H
#define ASM_H
int dequeue_value(int *buffer, int length, int *tail, int *head, int *value);
#endif