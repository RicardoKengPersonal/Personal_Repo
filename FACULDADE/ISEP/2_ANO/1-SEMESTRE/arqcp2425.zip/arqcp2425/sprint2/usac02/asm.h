int get_number_binary(int n, char* bits);
