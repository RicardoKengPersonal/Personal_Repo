int sort_array(int* vec, int length, char order);
