int get_number(char* str, int* n);
