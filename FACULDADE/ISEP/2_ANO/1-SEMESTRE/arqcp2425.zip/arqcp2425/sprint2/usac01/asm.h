int extract_data(char* str, char* token, char* unit, int* value);
