#ifndef ASM_H
#define ASM_H
int move_n_to_array(int *buffer, int length, int* tail, int* head, int n, int* array);
#endif