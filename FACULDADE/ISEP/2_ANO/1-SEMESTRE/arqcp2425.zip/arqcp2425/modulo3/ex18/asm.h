int sort_without_reps(short* ptrsrc, short* ptrdest,int num);
