#include <stdio.h>
#include "asm.h"

int main()
{
	
	return 0;
}
