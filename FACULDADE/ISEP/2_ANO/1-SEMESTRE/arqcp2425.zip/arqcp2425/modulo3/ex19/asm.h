void frequencies(char* ptrgrades, int num, int* ptrfreq);
