int five_count(char* ptr);
