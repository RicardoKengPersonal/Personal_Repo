int encrypt(char* ptr);
int decrypt(char* ptr);
