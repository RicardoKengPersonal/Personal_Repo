void str_copy_roman(char* ptr1, char* ptr2);
