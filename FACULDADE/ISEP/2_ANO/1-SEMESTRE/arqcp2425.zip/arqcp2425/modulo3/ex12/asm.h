unsigned char vec_zero(int* ptr, int num);
