int exists(int* ptr, int num, int x);
int vec_diff(int* ptr, int num);
