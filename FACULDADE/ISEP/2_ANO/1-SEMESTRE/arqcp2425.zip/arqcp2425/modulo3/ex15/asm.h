int sum_third_byte(long* ptr, int num);
