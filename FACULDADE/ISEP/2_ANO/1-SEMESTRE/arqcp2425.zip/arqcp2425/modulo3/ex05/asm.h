int vec_sum(int* ptr, short num);
int vec_avg(int* ptr, short num);

