void vec_add_three(short* ptr, int num);
