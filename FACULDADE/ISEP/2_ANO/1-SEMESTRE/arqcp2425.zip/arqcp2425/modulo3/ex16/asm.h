void swap(char* ptr1, char* ptr2, int num);
