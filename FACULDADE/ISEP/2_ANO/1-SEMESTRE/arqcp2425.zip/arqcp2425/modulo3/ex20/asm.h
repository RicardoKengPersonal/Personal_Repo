int count_max(int* ptr, int num);
