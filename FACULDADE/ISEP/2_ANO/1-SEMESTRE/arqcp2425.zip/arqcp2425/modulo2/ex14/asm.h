int getArea();
extern int length1,length2,height;
