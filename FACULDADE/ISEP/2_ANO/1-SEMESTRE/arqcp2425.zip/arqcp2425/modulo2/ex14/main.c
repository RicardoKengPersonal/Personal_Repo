#include <stdio.h>
#include "asm.h"


int main()
{
	printf("Result : %d\n",getArea());
	
	return 0;
}
