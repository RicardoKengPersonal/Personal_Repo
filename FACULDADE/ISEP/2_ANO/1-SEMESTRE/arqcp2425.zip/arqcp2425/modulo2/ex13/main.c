#include <stdio.h>
#include "asm.h"

short length1 = 2, length2 = 4, height = 5;

int main()
{
	printf("Result : %d\n",getArea());
	
	return 0;
}
