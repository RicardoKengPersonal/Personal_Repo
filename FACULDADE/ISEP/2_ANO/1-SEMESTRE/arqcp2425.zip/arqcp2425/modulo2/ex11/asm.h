char verify_flags();
