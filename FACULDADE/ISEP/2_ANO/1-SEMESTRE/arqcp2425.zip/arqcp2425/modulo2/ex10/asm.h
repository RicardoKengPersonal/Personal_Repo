long long sum3ints();
