#include <stdio.h>
#include "asm.h"

int op1 = 1, op2 = 2, op3 = 3;

int main()
{
	printf("Result: %lld\n",sum3ints());
	
	return 0;
}
