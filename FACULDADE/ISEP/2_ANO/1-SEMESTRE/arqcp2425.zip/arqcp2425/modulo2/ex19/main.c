#include <stdio.h>
#include "asm.h"

char current = 20;  
char desired = 21;

int main()
{
	
	printf("\nNeeded time %d seconds.\n",needed_time());
	
	return 0;
}
