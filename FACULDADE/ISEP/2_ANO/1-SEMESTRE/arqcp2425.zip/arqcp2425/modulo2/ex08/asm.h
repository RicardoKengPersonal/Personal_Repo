short crossSubBytes();
extern short s1,s2;
