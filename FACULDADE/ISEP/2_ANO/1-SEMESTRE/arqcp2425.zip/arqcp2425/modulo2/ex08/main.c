#include <stdio.h>
#include "asm.h"


int main()
{
    printf("\nResult: %d\n", crossSubBytes());
    
    return 0;
}
