#include <stdio.h>
#include "asm.h"

int A = 2, B = 5, C = 3, D = 4;

int main()
{
	printf("Result: %d\n",compute());
	
	return 0;
}
