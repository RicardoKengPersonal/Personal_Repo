#include <stdio.h>
#include "sigma.h"

int n;

int main() {
	n=3;
    int result = sigma();
    printf("Result: %d\n", result);
    return 0;
}
