#ifndef SIGMA_H
#define SIGMA_H
    int sigma();
#endif
