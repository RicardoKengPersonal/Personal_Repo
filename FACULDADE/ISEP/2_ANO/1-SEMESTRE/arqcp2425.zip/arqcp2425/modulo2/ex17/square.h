int square();
