char isMultiple();
