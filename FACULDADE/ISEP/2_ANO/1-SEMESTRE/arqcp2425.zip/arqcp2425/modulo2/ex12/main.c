#include <stdio.h>
#include "asm.h"

int A = 4, B = 2;

int main()
{
	printf("Result: %d\n",isMultiple());
	return 0;
}
