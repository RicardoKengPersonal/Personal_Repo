#include <stdio.h>
#include "asm.h"

long num = 20;

int main()
{
	printf("Result: %d\n",steps());
	
	return 0;
}
