int count_max(int* ptr, int num);
int max(int a, int b, int c);
