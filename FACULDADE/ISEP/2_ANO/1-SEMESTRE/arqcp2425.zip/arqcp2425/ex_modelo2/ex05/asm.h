int fn(long *ptr);
