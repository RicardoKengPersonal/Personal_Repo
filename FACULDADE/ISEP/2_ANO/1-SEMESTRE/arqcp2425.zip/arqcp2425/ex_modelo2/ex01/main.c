#include <stdio.h>
#include "asm.h"

int main()
{
	int r = max(1,3,2);
	printf("%d\n",r);
	
	return 0;
}
