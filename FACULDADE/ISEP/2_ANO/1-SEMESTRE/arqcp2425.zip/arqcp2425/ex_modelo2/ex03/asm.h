char fn(int* ptr);
