int remove_spaces(char* str);
