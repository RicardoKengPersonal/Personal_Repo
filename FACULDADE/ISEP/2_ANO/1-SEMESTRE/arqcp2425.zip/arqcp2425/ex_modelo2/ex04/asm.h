char* find_result(char* str, char* token);
