#ifndef FILE_H
#define FILE_H

// COMMIT DA BRUNA

int format_command(char* op, int n, char* cmd);
int get_number_binary(int n, char* bits);
int extract_data(char* str, char* token, char* unit, int* value);
int median(int* vec, int length, int *me);
int sort_array(int* vec, int length, char order);

#endif
